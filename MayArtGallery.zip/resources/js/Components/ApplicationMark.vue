<template>
            <img src  = "images/art_logo.png" alt = "logo" class = "rounded-lg w-20 h-20" ></img>

</template>
