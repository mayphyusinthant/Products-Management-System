<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
        <img src  = "images/art_logo.png" alt = "logo" class = "rounded-lg w-24" ></img>
    </Link>
</template>
