<script setup>
import { onMounted, ref } from 'vue';

defineProps({
    value: String,
});

import { getCookie } from '@/utils'; // Adjust the path based on your project structure

    let darkMode = null;

    onMounted(() => {
      if(getCookie('darkMode') == 'on'){
        darkMode = true;
      }else{
        darkMode = false;
      }

      console.log(darkMode)
    });

</script>

<template>
    <label class="block font-medium text-sm text-gray-700" 
    :class="{ 'dark:text-white': darkMode }">
        <span v-if="value">{{ value }}</span>
        <span v-else><slot /></span>
    </label>
</template>
