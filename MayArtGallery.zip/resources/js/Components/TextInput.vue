<script setup>
import { onMounted, ref } from 'vue';

defineProps({
    modelValue: String,
});

defineEmits(['update:modelValue']);

const input = ref(null);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

defineExpose({ focus: () => input.value.focus() });

import { getCookie } from '@/utils'; // Adjust the path based on your project structure

let darkMode = null;

onMounted(() => {
  if(getCookie('darkMode') == 'on'){
    darkMode = true;
  }else{
    darkMode = false;
  }

  console.log(darkMode)
});
</script>

<template>
    <input
        ref="input"
        class=" border-gray-300 focus:border-pink-400 focus:ring-pink-400 rounded-md shadow-sm form-input w-full"
        
        :value="modelValue"
        @input="$emit('update:modelValue', $event.target.value)"
    >
</template>
