<?php

namespace App\Http\Controllers;
use App\Models\Item;
use Illuminate\Validation\ValidationException;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;


class ItemController extends Controller
{
    public function index()
    {
        return Inertia::render('Item/Index', [
            "items" => Item::all()
        ]);
    }

    public function create()
    {
        return Inertia::render('Item/Create', [
            'edit' => false,
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
        'name' => ['required', 'string', 'max:255'],
        'description' => ['required', 'string', 'max:255'],
        'artType' => ['required', 'string', 'max:255'],
        'medium' => ['required', 'string', 'max:255'],
        'size' => ['required'],
        'price' => ['required', 'integer'],
        'status' => ['required', 'string', 'max:255'],
        'img' => ['required']
    ]);

    if ($validator->fails()) {
        
        // If validation fails, return with errors
        throw ValidationException::withMessages($validator->errors()->toArray());
    }
    
    // Validation passed, create the item
    $validatedData = $validator->validated();
    $validatedData['img'] = 'images/' .basename($request->input('img'));
    $validatedData['size'] = $request->input('size');
    Item::create($validatedData);


    // Redirect or render as needed
    return  Redirect::route('items.index')->with('success', 'New Item has been created successfully.');
    }


    public function edit(Request $request, $id){
        $item = Item::find($id);
        if(!$item){
            return redirect("/items")->with('error', 'Item not found.');
        }

        return Inertia::render('Item/Create', [
            'edit' => true,
            'item' => $item,
        ]);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
        'name' => ['required', 'string', 'max:255'],
        'description' => ['required', 'string', 'max:255'],
        'artType' => ['required', 'string', 'max:255'],
        'size' => ['required', 'string', 'max:255'],
        'medium' => ['required', 'string', 'max:255'],
        'price' => ['required', 'integer'],
        'status' => ['required', 'string', 'max:255'],
        'img' => ['required']
    ]);

    if ($validator->fails()) {
        // If validation fails, return with errors
        throw ValidationException::withMessages($validator->errors()->toArray());
    }

    if($validator->validated()){
        $item = Item::find($id);
        $item->name = $request->input('name');
        $item->description = $request->input('description');
        $item->artType = $request->input('artType');
        $item->size = $request->input('size');
        $item->medium = $request->input('medium');
        $item->price = $request->input('price');
        $item->status = $request->input('status');
        $item->img = 'images/' .basename($request->input('img'));

        $item->save();
        // Redirect or render as needed
        return  Redirect::route('items.index')->with('success', 'Item has been updated successfully.');
    }
    
    }

    public function delete($id){
        $item = Item::find($id);
        if(!$item){
            return redirect("/items")->with('error', 'Item not found.');
        }
        else{
            $item->delete();
            return  redirect("/items")->with('success', 'Item has been deleted successfully.');

        }
    }
}
